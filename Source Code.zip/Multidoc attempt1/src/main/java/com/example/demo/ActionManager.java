// Define the package for the class
package com.example.demo;

// Import necessary JavaFX classes
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.WritableImage;
import java.util.ArrayDeque;
import java.util.Deque;

// Define the ActionManager class
public class ActionManager {

    // Deque to store undo actions
    private final Deque<WritableImage> undoActions;
    // Deque to store redo actions
    private final Deque<WritableImage> redoActions;
    // Reference to the canvas being managed
    private final Canvas canvas;
    // Reference to the graphics context of the canvas
    private final GraphicsContext graphicsContext;

    // Constructor to initialize the ActionManager with the canvas and graphics context
    public ActionManager(Canvas canvas, GraphicsContext graphicsContext) {
        // Initialize the Deques
        this.undoActions = new ArrayDeque<>();
        this.redoActions = new ArrayDeque<>();
        // Set references to the canvas and graphics context
        this.canvas = canvas;
        this.graphicsContext = graphicsContext;
        // Save the initial state of the canvas
        saveState();
    }

    // Method to save the current state of the canvas
    public void saveState() {
        // Push a snapshot of the current canvas onto the undoActions deque
        undoActions.push(canvas.snapshot(null, null));
        // Clear the redoActions deque, as a new action is performed
        redoActions.clear();
    }

    // Method to perform undo action
    public void undo() {
        // Check if there is more than one state in the undoActions deque
        if (undoActions.size() > 1) {
            // Pop the current state and push it onto the redoActions deque
            redoActions.push(undoActions.pop());
            // Get the previous state without removing it from the undoActions deque
            WritableImage previousState = undoActions.peek();
            // Clear the canvas and draw the previous state
            clearCanvas();
            graphicsContext.drawImage(previousState, 0, 0);
        }
    }

    // Method to perform redo action
    public void redo() {
        // Check if there are redo actions available
        if (!redoActions.isEmpty()) {
            // Pop the redo action and push it onto the undoActions deque
            WritableImage redoAction = redoActions.pop();
            undoActions.push(redoAction);
            // Get the next state without removing it from the undoActions deque
            WritableImage nextState = undoActions.peek();
            // Clear the canvas and draw the next state
            clearCanvas();
            graphicsContext.drawImage(nextState, 0, 0);
        }
    }

    // Private method to clear the canvas
    private void clearCanvas() {
        graphicsContext.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }
}
