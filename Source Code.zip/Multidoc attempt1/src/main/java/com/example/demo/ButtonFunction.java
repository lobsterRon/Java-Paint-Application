// Define the package for the class
package com.example.demo;

// Define the ButtonFunction class, which extends HelloController
public class ButtonFunction extends HelloController {

    // Static method to set the brush tool as active
    public static void Brush() {
        brushClicked = true;
        eraserClicked = false;
        textClicked = false;
    }

    // Static method to set the eraser tool as active
    public static void Eraser() {
        eraserClicked = true;
        brushClicked = false;
        textClicked = false;
    }

    // Static method to set the text tool as active
    public static void Text() {
        textClicked = true;
        brushClicked = false;
        eraserClicked = false;
    }
}
