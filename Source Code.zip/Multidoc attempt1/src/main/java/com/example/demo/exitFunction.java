// Define the package for the class
package com.example.demo;

// Import necessary JavaFX classes
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

// Define the exitFunction class
public class exitFunction {

    // Static method to handle the exit functionality
    public static void Exit() {
        Alert Exit = new Alert(Alert.AlertType.CONFIRMATION); // Message for confirmation
        Exit.setTitle("Exit");
        Exit.setHeaderText(null);
        Exit.setContentText("Do you want to exit the drawing application?");

        // Define exit and cancel buttons for the confirmation dialog
        ButtonType exit = new ButtonType("Exit");
        ButtonType cancel = new ButtonType("Cancel");
        Exit.getButtonTypes().setAll(exit, cancel);

        // Show the confirmation dialog and handle the user's response
        Exit.showAndWait().ifPresent(response -> {
            if (response == exit) {
                // If the user chooses to exit, terminate the application
                System.exit(0);
            }
        });
    }
}
