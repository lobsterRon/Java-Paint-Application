// Define the package for the class
package com.example.demo;

// Import necessary JavaFX printing classes
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.canvas.Canvas;
import javafx.scene.transform.Scale;

// Define the PrintController class
public class PrintController {

    // Instance variable to store the canvas to be printed
    private Canvas canvas;

    // Setter method to set the canvas
    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
    }

    // Method to initiate the printing process
    public void print() {
        // Handle the case when the canvas is not set
        if (canvas == null) return;

        // Create a PrinterJob for printing
        PrinterJob printerJob = PrinterJob.createPrinterJob();

        if (printerJob != null) {
            // Show the print dialog and proceed if the user clicks "Print"
            boolean success = printerJob.showPrintDialog(canvas.getScene().getWindow());

            if (success) {
                // Get the page layout settings from the printer job
                PageLayout pageLayout = printerJob.getJobSettings().getPageLayout();

                // Calculate scaling factors for width and height separately
                double scaleX = pageLayout.getPrintableWidth() / canvas.getWidth();
                double scaleY = pageLayout.getPrintableHeight() / canvas.getHeight();

                // Calculate the scaling factor that fits both dimensions
                double scaleFactor = Math.min(scaleX, scaleY);

                // Apply the scaling and translation transformations to the canvas
                // The Scale class is used for scaling transformations
                canvas.getTransforms().add(new Scale(scaleFactor / 2.5, scaleFactor / 2.5));

                // Print the content of the canvas
                boolean printed = printerJob.printPage(canvas);

                // End the print job if the content is successfully printed
                if (printed) {
                    printerJob.endJob();
                }
            }
        }
        // Remove the transformations after printing to avoid affecting the display
        canvas.getTransforms().clear();
    }
}
