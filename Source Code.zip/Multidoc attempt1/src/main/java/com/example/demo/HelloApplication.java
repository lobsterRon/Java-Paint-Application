// Define the package for the class
package com.example.demo;

// Import necessary JavaFX and IO classes
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;

// Define the main class that extends the JavaFX Application class
public class HelloApplication extends Application {

    // Override the start method to configure and display the JavaFX application
    @Override
    public void start(Stage stage) throws IOException {
        // Create an FXMLLoader to load the FXML file for the UI
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        // Create a Scene and set its content by loading the FXML file
        Scene scene = new Scene(fxmlLoader.load(), 835, 652);

        // Load the application icon (logo.png) and set it as the stage icon
        Image icon = new Image(HelloApplication.class.getResource("logo.png").openStream());
        stage.getIcons().add(icon);

        // Set the title of the stage
        stage.setTitle("Paint Application");

        // Set the scene for the stage
        stage.setScene(scene);

        // Show the stage (display the UI)
        stage.show();
    }

    // The main method to launch the JavaFX application
    public static void main(String[] args) {
        // Launch the JavaFX application
        launch();
    }
}
