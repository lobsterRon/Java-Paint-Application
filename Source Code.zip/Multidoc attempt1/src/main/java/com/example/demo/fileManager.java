// Define the package for the class
package com.example.demo;

// Import necessary JavaFX and IO classes
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

// Define the fileManager class
public class fileManager {

    // Attributes
    private boolean existingFile = false;
    private String currentFilePath;
    private boolean canvasSaved = false;
    public boolean saveAs = false; // Determine whether the user clicked save or save as
    private final ButtonType yes = new ButtonType("Yes");
    private final ButtonType no = new ButtonType("No");

    // Method to save the canvas as an image file
    public void save(Canvas canvas) {
        WritableImage writableImage = new WritableImage(736, 466);
        SnapshotParameters parameters = new SnapshotParameters();

        File file;
        if (!existingFile || saveAs) {
            Alert backgroundSetting = new Alert(Alert.AlertType.CONFIRMATION); // Message for confirmation
            backgroundSetting.setTitle("Background Configuration");
            backgroundSetting.setHeaderText(null);
            backgroundSetting.setContentText("Do you want to set the background as transparent?");

            // Set the buttons onto the alert
            backgroundSetting.getButtonTypes().setAll(yes, no);
            backgroundSetting.showAndWait().ifPresent(response -> {
                if (response == yes) {
                    parameters.setFill(Color.TRANSPARENT); // Set background to transparent if needed
                }
            });

            try {
                file = getSavePath(canvas);
                if (file == null) {
                    throw new IOException();
                }
            } catch (IOException e) {
                // Handle the case when the user cancels the save dialog
                Alert saveCanceled = new Alert(Alert.AlertType.INFORMATION);
                saveCanceled.setTitle("Information");
                saveCanceled.setHeaderText(null);
                saveCanceled.setContentText("Save operation canceled");
                saveCanceled.show();
                return;
            }
            if (saveAs) {
                saveAs = false;
            }
        } else {
            file = new File(currentFilePath);
        }
        // Capture the canvas content
        canvas.snapshot(parameters, writableImage);

        try {
            ImageIO.write(SwingFXUtils.fromFXImage(writableImage, null), "png", file);
            // Converts an Image object from JavaFX into a BufferedImage object from the Swing framework
            currentFilePath = file.getAbsolutePath();
            Alert savedMsg = new Alert(Alert.AlertType.INFORMATION); // Message for confirmation
            savedMsg.setTitle("Save Confirmation");
            savedMsg.setHeaderText(null);
            savedMsg.setContentText("Image saved");
            savedMsg.show();
            existingFile = true;
            canvasSaved = true;
        } catch (IOException e) {
            Alert saveFailed = new Alert(Alert.AlertType.INFORMATION);
            saveFailed.setTitle("Information");
            saveFailed.setHeaderText(null);
            saveFailed.setContentText("Save failed");
            saveFailed.show();
        }
    }

    // Method to open an image file and display it on the canvas
    public void open(Canvas canvas, GraphicsContext gc) {
        saveConfirmation(canvas);
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");

        // Set an extension filter (optional)
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png"),
                new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG files (*.jpeg)", "*.jpeg"),
                new FileChooser.ExtensionFilter("BITMAP files (*.bmp)", "*.bmp"),
                new FileChooser.ExtensionFilter("All Images", "*.png", "*.jpg", "*.jpeg", "*.bmp")
        );
        File selectedFile = fileChooser.showOpenDialog(canvas.getScene().getWindow());

        if (selectedFile != null) {
            try {
                gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                String filePath = selectedFile.getAbsolutePath();
                Image selectedImg = new Image(new File(filePath).toURI().toString());
                gc.drawImage(selectedImg, 0, 0);
                existingFile = true;
                currentFilePath = filePath;
            } catch (Exception e) {
                Alert openUnsuccessful = new Alert(Alert.AlertType.ERROR); // Message for confirmation
                openUnsuccessful.setTitle("Open Unsuccessful");
                openUnsuccessful.setHeaderText(null);
                openUnsuccessful.setContentText("This file can't be open by the paint application");
                openUnsuccessful.show();
            }
        }
    }

    // Method to create a new canvas
    public void New(Canvas canvas, GraphicsContext gc) {
        saveConfirmation(canvas);
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        existingFile = false;
    }

    // Method to get the save path for the canvas
    public static File getSavePath(Canvas canvas) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Image");

        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png"),
                new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG files (*.jpeg)", "*.jpeg"),
                new FileChooser.ExtensionFilter("BITMAP files (*.bmp)", "*.bmp"),
                new FileChooser.ExtensionFilter("All Images", "*.png", "*.jpg", "*.jpeg", "*.bmp")
        );
        return fileChooser.showSaveDialog(canvas.getScene().getWindow());
    }

    // Method to show a save confirmation dialog if the canvas is not saved
    public void saveConfirmation(Canvas canvas) {
        if (!canvasSaved) {
            Alert saveConfirmation = new Alert(Alert.AlertType.WARNING); // Message to remind the user to save
            saveConfirmation.setTitle("Current File not Saved");
            saveConfirmation.setHeaderText(null);
            saveConfirmation.setContentText("The current file has not been saved yet. Do you want to save it?");
            saveConfirmation.getButtonTypes().setAll(yes, no);
            saveConfirmation.showAndWait().ifPresent(response -> {
                if (response == yes) {
                    save(canvas);
                } else {
                    canvasSaved = true;
                }
            });
        }
    }
}
