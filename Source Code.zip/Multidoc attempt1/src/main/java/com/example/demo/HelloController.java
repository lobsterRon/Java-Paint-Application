// Define the package for the class
package com.example.demo;

// Import necessary JavaFX, IO, and utility classes
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// Define the controller class that implements the Initializable interface
public class HelloController implements Initializable {

    // Injecting FXML elements from the corresponding FXML file
    @FXML
    public Canvas canvas;
    @FXML
    private Slider ThicknessSlide;
    @FXML
    private Text ThicknessValue;
    @FXML
    private ColorPicker colorPicker;
    @FXML
    private TextField textInput;
    @FXML
    private Button btnBrush;
    @FXML
    private Button btnEraser;
    @FXML
    private Button btnFill;
    @FXML
    private Button btnClear;
    @FXML
    private Button btnTxtBox;
    @FXML
    private Text lblThickness;
    @FXML
    private Pane myPane;

    // Boolean variables to track the state of various tools
    boolean value = true;
    @FXML
    static boolean brushClicked = false;
    static boolean eraserClicked = false;
    static boolean textClicked = false;

    // Instances of utility classes
    fileManager FileManager = new fileManager();
    GraphicsContext brushTool;
    private ActionManager undoRedoFunction;
    PrintController printController = new PrintController();
    int i = 0;

    // Implementation of the initialize method from the Initializable interface
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Get the GraphicsContext for the canvas
        brushTool = canvas.getGraphicsContext2D();
        // Initialize the undo-redo functionality
        undoRedoFunction = new ActionManager(canvas, brushTool);

        // Set up initial visibility and properties of UI elements
        textInput.setVisible(false);
        ThicknessSlide.valueProperty().addListener((observableValue, number, t1) -> {
            double bSize = ThicknessSlide.getValue();
            ThicknessValue.setText(Integer.toString((int) bSize));
        });

        // Handle mouse-dragged events on the canvas
        canvas.setOnMouseDragged(e -> {
            double bSize = ThicknessSlide.getValue();
            double x = e.getX() - bSize / 2; // This formula aligns get the exact mouse coordinates
            double y = e.getY() - bSize / 2;

            if (brushClicked) {
                brushTool.setFill(colorPicker.getValue());
                brushTool.fillRoundRect(x, y, bSize, bSize, bSize, bSize);
            } else if (eraserClicked) {
                brushTool.clearRect(x, y, bSize, bSize);
            } else if (textClicked) {
                textInput.setVisible(true);
                textInput.requestFocus();
            }
        });

        // Handle mouse-released events on the canvas
        canvas.setOnMouseReleased(e -> undoRedoFunction.saveState());

        // Handle key events for text input
        textInput.setOnKeyPressed(event -> {
            if (event.getCode().equals(KeyCode.ENTER)) {
                i += 15;
                String enteredText = textInput.getText();
                brushTool.setFill(colorPicker.getValue());
                brushTool.fillText(enteredText, textInput.getLayoutX() + 1, textInput.getLayoutY() + i);
                textInput.clear();
                textInput.setVisible(false);
                textClicked = false;
                undoRedoFunction.saveState();
            }
        });

        // Handle key events for shortcut keys
        myPane.setOnKeyPressed(event -> {
            if (event.isControlDown() && (event.getCode() == KeyCode.Z)) {
                UndoClicked();
            } else if (event.isControlDown() && (event.getCode() == KeyCode.Y)) {
                RedoClicked();
            } else if (event.isControlDown() && (event.getCode() == KeyCode.S)) {
                saveClicked();
            } else if (event.isControlDown() && (event.getCode() == KeyCode.N)) {
                newClicked();
            }
        });
    }

    // Method to handle the "Clear" button click
    public void clearClicked() {
        i = 0;
        brushTool.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        undoRedoFunction.saveState();
    }

    // Method to handle the "Fill" button click
    public void fillClicked() {
        brushTool.setFill(colorPicker.getValue());
        brushTool.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        undoRedoFunction.saveState();
    }

    // Method to handle the "Brush" tool click
    public void toolClicked() {
        ButtonFunction.Brush();
        textInput.setVisible(false);
    }

    // Method to handle the "Eraser" tool click
    public void eraserClicked() {
        ButtonFunction.Eraser();
        textInput.setVisible(false);
    }

    // Method to handle the "Text" tool click
    public void textClicked() {
        ButtonFunction.Text();
        textInput.setVisible(true);
    }

    // Method to handle the "Exit" button click
    public void exitClicked() {
        exitFunction.Exit();
    }

    // Method to handle the "Save" button click
    public void saveClicked() {
        FileManager.save(canvas);
    }

    // Method to handle the "Save As" button click
    public void saveasClicked() {
        FileManager.saveAs = true;
        FileManager.save(canvas);
    }

    // Method to handle the "Open" button click
    public void openClicked() {
        FileManager.open(canvas, brushTool);
    }

    // Method to handle the "New" button click
    public void newClicked() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 835, 652);

            Stage stage = new Stage();
            stage.setScene(scene);
            Image icon = new Image(HelloApplication.class.getResource("logo.png").openStream());
            stage.getIcons().add(icon);
            stage.setTitle("Paint Application");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to handle the "Print" button click
    @FXML
    public void printClicked() {
        printController.setCanvas(canvas);
        printController.print();
    }

    // Method to handle the "About" button click
    public void aboutClicked() {
        About.ShowAbout();
    }

    // Method to toggle the visibility of the toolbox
    public void ToolBoxClicked() {
        value = !value;
        btnBrush.setVisible(value);
        btnEraser.setVisible(value);
        btnClear.setVisible(value);
        btnTxtBox.setVisible(value);
        btnFill.setVisible(value);
        lblThickness.setVisible(value);
        ThicknessValue.setVisible(value);
        ThicknessSlide.setVisible(value);
    }

    // Method to toggle the visibility of the color picker
    public void ColorBoxClicked() {
        value = !value;
        colorPicker.setVisible(value);
    }

    // Method to handle the "Undo" button click
    public void UndoClicked() {
        undoRedoFunction.undo();
    }

    // Method to handle the "Redo" button click
    public void RedoClicked() {
        undoRedoFunction.redo();
    }
}
