// Define the package for the class
package com.example.demo;

// Import necessary JavaFX classes
import javafx.scene.control.Alert;
import javafx.scene.image.Image;

// Define the About class
public class About {

    // Static method to display information about the project
    public static void ShowAbout() {
        // Create an information alert for displaying about information
        Alert aboutMsg = new Alert(Alert.AlertType.INFORMATION);
        aboutMsg.setTitle("About");
        aboutMsg.setHeaderText(null);

        // Set the content of the alert with information about the project
        aboutMsg.setContentText("This project requires us to develop a productivity tool using Java. As such, we plan to \n" +
                "develop a drawing tool using Java that can fulfill basic drawing needs. Basic functionalities in \n" +
                "the application include:-\n" +
                "\uF09F Various colors\n" +
                "\uF09F Various brushes\n" +
                "\uF09F Ability to add text\n" +
                "\uF09F Eraser tool\n" +
                "\uF09F Save & export.\n" +
                "\uF09F Brush thickness\n" +
                "\uF09F Eraser\n" +
                "\uF09F Color fill\n" +
                "\uF09F Text box\n" +
                "\n" +
                "This coding also includes some shortcut keys, as follows :-\n" +
                "\uF09F Undo : CTRL + Z\n" +
                "\uF09F Redo : CTRL + Y\n" +
                "\uF09F Save : CTRL + S\n" +
                "\uF09F New File : CTRL + N\n" +
                "\n" +
                "We hope that you have a convenient time using this Simple Drawing App by The Rizzlers\n" +
                "Riz, Afif, Cheah, Amira, Maryam, and Shahir");

        // Show the alert to display the about information
        aboutMsg.show();
    }
}
